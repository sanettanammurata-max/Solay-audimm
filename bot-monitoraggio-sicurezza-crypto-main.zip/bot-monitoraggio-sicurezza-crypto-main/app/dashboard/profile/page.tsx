import { desc, eq } from 'drizzle-orm'
import { redirect } from 'next/navigation'
import RadarProfile from '@/components/RadarProfile'
import { getVerifiedSession } from '@/app/actions/session'
import { db } from '@/lib/db'
import { monitoredWallet, securityUser } from '@/lib/db/schema'

export default async function ProfilePage() {
  const session = await getVerifiedSession()
  if (!session) redirect('/dashboard')

  const user = (await db.select().from(securityUser).where(eq(securityUser.id, session.userId)).limit(1))[0]
  if (!user) redirect('/dashboard')

  const wallets = await db.select().from(monitoredWallet).where(eq(monitoredWallet.userId, user.id)).orderBy(desc(monitoredWallet.createdAt))
  return <RadarProfile telegramChatId={session.chatId} isPremium={user.isPremium} initialWallets={wallets.map((wallet) => ({ id: wallet.id, blockchain: wallet.blockchain as 'BITCOIN' | 'ETHEREUM' | 'SOLANA' | 'STELLAR' | 'XRP', walletAddress: wallet.walletAddress, webhookId: wallet.webhookId, createdAt: wallet.createdAt.toISOString() }))} />
}
