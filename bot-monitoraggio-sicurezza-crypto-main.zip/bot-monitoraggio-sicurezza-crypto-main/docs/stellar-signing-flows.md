# Stellar Mainnet Signing Flow Architecture for LOBSTR

To enable real USDC subscription payments ($9.00/mo) from LOBSTR without placeholder simulations or fragile browser extensions, the frontend must implement one of the two official Stellar signing standards.

## Option A: SEP-0007 (Stellar URL Scheme / Deep Linking)

SEP-0007 is the lightweight, mobile-first approach for wallets such as LOBSTR. The server builds an unsigned transaction XDR, converts it into a standardized Stellar URI, and the client presents it as a deep link or QR code.

### Production flow

1. **Server-side build:** A Server Action creates a raw, unsigned transaction XDR containing the payment operation: `9.0000000 USDC` to `GBDZ5E7ENT5T3SUKGAU5KEVFGUKWIGKQFH45EZV4IRUHPYVI6Y7PTELI`.
2. **URI construction:** The XDR is encoded into a Stellar URI:

   ```text
   web+stellar:tx?xdr=AAAAAgAAAA...&callback=https://sentinella.app/api/payments/stellar/callback
   ```

3. **Wallet handoff:** On desktop, Sentinella displays a QR code. On mobile, a button opens the LOBSTR deep link.
4. **User approval:** LOBSTR decodes the XDR and prompts the user for biometric or PIN approval.
5. **Callback and verification:** The callback receives a transaction reference. The server fetches the transaction from Horizon and independently verifies the network, successful result, destination, asset issuer, amount, source account, and replay status before granting Premium.

### Strengths and constraints

- Minimal client dependencies and strong mobile compatibility.
- No private keys are handled by Sentinella.
- Callback delivery must be treated as untrusted input; it is never proof of payment by itself.
- The payment intent must be short-lived and bound to the authenticated session.

## Option B: WalletConnect v2

WalletConnect is appropriate for a richer desktop dApp experience with a persistent wallet session.

### Production flow

1. **Session establishment:** The client initializes a WalletConnect-compatible Stellar connector and presents a pairing QR code.
2. **Pairing:** The user opens LOBSTR and scans the code. An encrypted session is established through the relay.
3. **Transaction dispatch:** The client sends the unsigned transaction XDR through the supported Stellar signing method.
4. **Signature capture:** LOBSTR returns a signed XDR after user approval.
5. **Submission and verification:** A server-controlled route submits the signed envelope to Horizon, obtains the real transaction hash, and verifies the completed payment before updating the user record.

The exact JSON-RPC method and namespace must be confirmed against LOBSTR's current WalletConnect support before implementation. Do not hardcode an unverified method name or assume generic EVM WalletConnect behavior applies to Stellar.

## Security requirements

- Generate transaction envelopes server-side with a fresh sequence number and a short timeout.
- Store a payment intent containing the authenticated user ID, expected network, receiver, asset issuer, amount, expiration, and a unique nonce.
- Enforce one-time use of each transaction hash and payment intent.
- Verify the transaction on Horizon server-side; never trust amount, receiver, asset, or status supplied by the browser or callback.
- Reject testnet transactions when Premium is configured for Mainnet.
- Keep the company receiver and asset issuer in server environment variables, never in client-controlled input.
- Rate-limit payment verification and record rejected attempts for auditability.

## Infrastructure checklist

- [ ] Choose SEP-0007 for the initial mobile-first implementation, or WalletConnect after confirming LOBSTR's current Stellar support.
- [ ] Install `@stellar/stellar-sdk` only when implementing server-side transaction construction and XDR parsing.
- [ ] Add a Drizzle payment-intent table with session ownership, nonce, expected payment terms, expiration, and consumed status.
- [ ] Add a signed or authenticated callback route if SEP-0007 callback support is used.
- [ ] Verify the final transaction against Horizon before setting `isPremium = true`.
- [ ] Add integration tests for replay, wrong asset issuer, wrong network, wrong receiver, wrong amount, and expired intents.

## Recommended implementation order

1. Implement payment intents and server-side XDR generation.
2. Implement the SEP-0007 handoff and QR/deep-link UI.
3. Implement Horizon verification and idempotent Premium activation.
4. Add WalletConnect only if the product requires a persistent desktop wallet session.
